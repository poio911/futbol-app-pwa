/**
 * BACKUP NOTE:
 * No se removieron bloques completos en app.js. Solo se añadieron guardas y comentarios.
 * El archivo original aceptado antes de la auditoría permanece funcionalmente equivalente.
 */
