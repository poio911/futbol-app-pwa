/**
 * BACKUP FRAGMENT - Duplicated tail removed from ui.js (incoherent block).
 * Este bloque estaba fuera del objeto UI y provocaba errores de sintaxis.
 */

/*
        this.elements.previewName.textContent = 'Nombre del Jugador';
        this.elements.previewPosition.textContent = 'POS';
        this.elements.previewOvr.textContent = '50';
        // Reset sliders ...
    },

    showNotification(message, type = 'success') { ...duplicado... },

    showSetupComplete(person, group) { ... },
    showGroupCreated(group) { ... },
    showGroupJoined(group) { ... }
*/
